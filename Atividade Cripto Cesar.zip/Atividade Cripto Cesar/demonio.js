const alfa = "abcdefghijklmnopqrstuvwxyz";
const salto = 3;

function criptografar(mensagem, salto) {
    mensagem = mensagem.toLowerCase();
    let segredo = "";

    for (let letra of mensagem) {
        let posicao = alfa.indexOf(letra);
        if (posicao !== -1) {
            posicao = (posicao + salto) % alfa.length;
            segredo += alfa[posicao];
        } else {
            segredo += letra;
        }
    }
    return segredo;
}

function descriptografar(mensagem, salto) {
    let segredo = "";

    for (let letra of mensagem) {
        let posicao = alfa.indexOf(letra);
        if (posicao !== -1) {
            posicao = (posicao - salto + alfa.length) % alfa.length;
            segredo += alfa[posicao];
        } else {
            segredo += letra;
        }
    }
    return segredo;
}

// Teste no console
const msg = prompt("Digite o texto a ser criptografado:");
const msgCripto = criptografar(msg, salto);
console.log("Mensagem criptografada:", msgCripto);

const msgDescripto = descriptografar(msgCripto, salto);
console.log("Mensagem descriptografada:", msgDescripto);
