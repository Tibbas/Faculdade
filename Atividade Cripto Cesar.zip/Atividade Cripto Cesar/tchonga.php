<?php
$alfa = "abcdefghijklmnopqrstuvwxyz";
$salto = 3;

function criptografar($mensagem, $salto, $alfa) {
    $mensagem = strtolower($mensagem);
    $segredo = "";

    for ($i = 0; $i < strlen($mensagem); $i++) {
        $letra = $mensagem[$i];
        $posicao = strpos($alfa, $letra);
        
        if ($posicao !== false) {
            $posicao = ($posicao + $salto) % strlen($alfa);
            $segredo .= $alfa[$posicao];
        } else {
            $segredo .= $letra; // Mantém caracteres que não estão no alfabeto
        }
    }
    return $segredo;
}

function descriptografar($mensagem, $salto, $alfa) {
    $segredo = "";

    for ($i = 0; $i < strlen($mensagem); $i++) {
        $letra = $mensagem[$i];
        $posicao = strpos($alfa, $letra);
        
        if ($posicao !== false) {
            $posicao = ($posicao - $salto + strlen($alfa)) % strlen($alfa);
            $segredo .= $alfa[$posicao];
        } else {
            $segredo .= $letra;
        }
    }
    return $segredo;
}

// Teste
$msg = readline("Digite o texto a ser criptografado: ");
$msgCripto = criptografar($msg, $salto, $alfa);
echo "Mensagem criptografada: " . $msgCripto . "\n";

$msgDescripto = descriptografar($msgCripto, $salto, $alfa);
echo "Mensagem descriptografada: " . $msgDescripto . "\n";
?>
