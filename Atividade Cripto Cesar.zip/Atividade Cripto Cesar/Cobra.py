Salto = 3

alfa = 'abcdefghijklmnopqrstuvwxyz'

def criptografar(mensagem, salto):
    mensagem = mensagem.lower()
    segredo = ''
    
    for letra in mensagem:
        posicao = alfa.find(letra)
        if posicao != -1:
            posicao = (posicao + salto) % len(alfa)
            segredo += alfa[posicao]
        else:
            segredo += letra

    return segredo

def descriptografar(mensagem, salto):
    segredo = ''
    
    for letra in mensagem:
        posicao = alfa.find(letra)
        if posicao != -1:
            posicao = (posicao - salto) % len(alfa)
            segredo += alfa[posicao]
        else:
            segredo += letra  

    return segredo

msg = input('Digite o texto a ser criptografado: ')
msg_cripto = criptografar(msg, Salto)
print('Mensagem criptografada:', msg_cripto)

msg_descripto = descriptografar(msg_cripto, Salto)
print('Mensagem descriptografada:', msg_descripto)
