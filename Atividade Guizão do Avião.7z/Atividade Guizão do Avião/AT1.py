grau_celsius = float(input('Digite a temperatura em Celsius: '))
grau_fahrenheit = grau_celsius * 1.8 + 32
print(f'A temperatura de {grau_celsius} °C é igual a {grau_fahrenheit}°F.')
# o 'f' no print é para as {} funcionar.
