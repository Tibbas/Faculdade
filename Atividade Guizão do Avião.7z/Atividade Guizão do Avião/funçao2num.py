def soma_nr(n1,n2):
    x = n1 + n2
    return x

def mostra_resultado(m):
    print(f'A soma é igual a {m}.')

n1 = float(input('Digite o primeiro número: '))
n2 = float(input('Digite o segundo número: '))

soma = soma_nr(n1,n2)

mostra_resultado(soma)