

def converte_c_f(celsius):
    print(celsius)
    grau_f = celsius * 1.8 + 32
    return grau_f

grau_celsius = float(input('Digite a temperatura em Celsius: '))
grau_fahrenheit = converte_c_f(grau_celsius)
print(f'A temperatura de {grau_celsius} °C é igual a {grau_fahrenheit}°F.')