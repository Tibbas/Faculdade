def converter_km_m(km):
    milha_f = km * 1.60934
    return milha_f


km = float(input('Insira o valor em Km: '))
milha = converter_km_m(km)
print(f'A converção de km em milha é: {milha}')

