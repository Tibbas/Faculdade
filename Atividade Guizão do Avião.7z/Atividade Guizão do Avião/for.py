'''
for i in range(11):
    print(1)
'''

'''
nr_alunos = int(input('Digite o número de alunos: '))
for cont in range(1, nr_alunos + 1):
    nome_aluno = input(f'{cont} - Digite o nome do aluno: ')
'''

nr_alunos = int(input('Digite o número de alunos: '))
qtde_notas = int(input('Digite o número de notas: '))
notas = 0
for i in range(1, nr_alunos + 1):
    input(f'{i} - Digite o nome do aluno: ')

    for j in range(1, qtde_notas + 1):
        nota = float(input(f'Digite a {j}ª nota: '))
        notas += nota

    media = notas // qtde_notas
    print(f'A média do aluno {i} é {media}')
    notas = 0