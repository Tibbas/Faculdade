import streamlit as st

st.title('Conversor de temperatura Celsius para Fahrenheit')
st

# crlt + space abre varias coisas de css do st