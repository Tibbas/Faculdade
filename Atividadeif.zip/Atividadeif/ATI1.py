#exercicio 1:


'''num = int(input('Digite uma número: '))

if num > 0:
    print('O número é positivo')
elif num < 0:
    print('O número é negativo')
else :
    print("O número é igual zero")

    
#exercicio 2:


if num % 2 == 0 :
    print("o número é par")
else:
    print("O número é impar")

    
#exercicio 3:


age = int(input("Qual a sua idade?"))

if age >= 18:
    print('Tu é maior de idade')
else:
    print('Tu é menor de idade')
'''


#exercicio 4:


'''
nota = int(input('Digite sua nota:'))
if nota >= 9:
    print('Ótimo')
elif (nota >= 7 and nota <= 8.9):
    print('Bom')
elif (nota >= 5 and nota <= 6.9):
    print('Regular')
elif nota < 5:
    print('Reprovado')
    
"""


#exercicio 5


num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))
op= input("informe a operação desejada (1 para + ) (2 para -) (3 para *) (4 para /)")

if op == "1" :
    print(num1 + num2)
elif op == "2" :
    print(num1 - num2)
elif op == "3" :
    print(num1 * num2)
elif op == "4" :
    print(num1 / num2)

"""


#exercicio 6


"""
peso = float(input('Qual o seu peso?'))
altura = float(input('Qual o sua altura?'))

IMC = peso / altura

if IMC <= 18.4:
    print('Abaixo do peso')
elif IMC <= 18.5 and IMC < 24.9:
    print('Peso normal')
elif IMC <= 25 and IMC < 29.9:
    print('Sobrepeso')
elif IMC >= 30:
    print('Obesidade')"
    
""""


#exercicio 7


senha = (input('Digite a senha'))
if senha == 'jorgeébao22':
    print('passou')
else:
    print('senha incorreta')
"""

#exercicio 8



ano = int(input('Insira o ano para verificar se ele é bissexto:'))

if ano % 4 == 0:
    print('O ano é bisexto')
else:
    print('não é bisexto')
'''

#exercicios 9

'''
letra = str(input('Digite uma letra: '))
if letra == 'a' or letra == 'e' or letra == 'i' or letra == 'o' or letra == 'u':
    print('Sua letra é uma vogal!')
else:
    print('sua letra é uma consoante!')
'''


#exercicio 10


'''
num1 = int(input('Insira o 1º número: '))
num2 = int(input('Insira o 2º número: '))
num3 = int(input('Insira o 3º número: '))

if (num1 > num2) and (num1 > num3):
    print('O primeiro número é maior')
elif (num2 > num1) and (num2 > num3):
    print('O segundo número é maior')
else:
    print('O terceiro número é o maior')'


'''
